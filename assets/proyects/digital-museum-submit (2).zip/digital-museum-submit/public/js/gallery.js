// ─────────────────────────────────────────────────────────────────────────────
//  gallery.js
// ─────────────────────────────────────────────────────────────────────────────

const CATEGORY_ICONS = {
  Literature: '📖', Music: '🎵', Art: '🎨',
  Film: '🎬', Object: '🏺', Game: '🎲',
};

// ── State ─────────────────────────────────────────────────────────────────────
let allArtifacts      = [];
let activeCategory    = '';
let searchQuery       = '';
let currentArtifactId = null;   // id of whichever artifact is open in the detail modal

// ── DOM refs ──────────────────────────────────────────────────────────────────
const grid        = document.getElementById('artifact-grid');
const loading     = document.getElementById('loading');
const emptyState  = document.getElementById('empty-state');
const searchInput = document.getElementById('search-input');
const statCount   = document.getElementById('stat-artifacts');
const modal       = document.getElementById('modal');
const addModal    = document.getElementById('add-modal');
const addForm     = document.getElementById('add-form');

// ═════════════════════════════════════════════════════════════════════════════
//  HERO ANIMATION
// ═════════════════════════════════════════════════════════════════════════════

function animateHero() {
  setTimeout(() => { document.getElementById('hero-sub').style.opacity = '1'; }, 200);

  typeWords('hero-line-1', 'Objects That Were', 0, () => {
    typeWords('hero-line-2', 'Forbidden', 0, () => {
      setTimeout(() => {
        document.getElementById('hero-desc').style.opacity = '1';
        document.getElementById('scroll-cue').style.opacity = '1';
      }, 300);
    });
  });
}

function typeWords(elementId, text, startDelay, onDone) {
  const el    = document.getElementById(elementId);
  const chars = text.split('');
  chars.forEach((char, i) => {
    const span = document.createElement('span');
    span.className   = 'hero-char';
    span.textContent = char === ' ' ? '\u00A0' : char;
    el.appendChild(span);
    setTimeout(() => span.classList.add('visible'), startDelay + i * 45);
  });
  if (onDone) setTimeout(onDone, startDelay + chars.length * 45 + 200);
}

// ═════════════════════════════════════════════════════════════════════════════
//  SCROLL REVEAL
// ═════════════════════════════════════════════════════════════════════════════

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const cards = [...grid.querySelectorAll('.artifact-card')];
      const idx   = cards.indexOf(entry.target);
      setTimeout(() => entry.target.classList.add('visible'), idx * 80);
      revealObserver.unobserve(entry.target);
    });
  },
  { threshold: 0.1 }
);

// ═════════════════════════════════════════════════════════════════════════════
//  API CALLS
// ═════════════════════════════════════════════════════════════════════════════

async function fetchArtifacts(category = '', search = '') {
  showLoading();
  try {
    const params = new URLSearchParams();
    if (category) params.set('category', category);
    if (search)   params.set('search', search);

    const url = '/api/artifacts' + (params.toString() ? '?' + params : '');
    const res = await fetch(url);
    if (!res.ok) throw new Error('Network error');
    return await res.json();
  } catch (err) {
    console.error('fetchArtifacts:', err);
    return [];
  }
}

async function fetchArtifactById(id) {
  const res = await fetch(`/api/artifacts/${id}`);
  if (!res.ok) throw new Error('Not found');
  return res.json();
}

// Send multipart/form-data to POST /api/artifacts
async function createArtifact(formData) {
  const res = await fetch('/api/artifacts', { method: 'POST', body: formData });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || 'Failed to create artifact');
  }
  return res.json();
}

async function deleteArtifact(id) {
  const res = await fetch(`/api/artifacts/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete');
  return res.json();
}

// ═════════════════════════════════════════════════════════════════════════════
//  RENDERING
// ═════════════════════════════════════════════════════════════════════════════

function renderGallery(artifacts) {
  grid.innerHTML = '';

  if (artifacts.length === 0) {
    hideLoading();
    grid.classList.add('hidden');
    emptyState.classList.remove('hidden');
    return;
  }

  emptyState.classList.add('hidden');
  grid.classList.remove('hidden');
  grid.classList.add('grid');

  artifacts.forEach((artifact) => {
    const card = buildCard(artifact);
    grid.appendChild(card);
    revealObserver.observe(card);
  });

  hideLoading();
}

function buildCard(artifact) {
  const card = document.createElement('div');
  card.className = 'artifact-card bg-museum-card border border-museum-border rounded-xl overflow-hidden flex flex-col';
  card.dataset.id = artifact._id;

  const imageSection = artifact.image
    ? `<div class="relative h-44 overflow-hidden">
         <img src="${escHtml(artifact.image)}" alt="${escHtml(artifact.name)}"
              class="w-full h-full object-cover opacity-70"
              onerror="this.parentElement.style.background='linear-gradient(135deg,${artifact.color}33,${artifact.color}11)';this.remove()" />
         <div class="absolute inset-0 bg-gradient-to-t from-museum-card to-transparent"></div>
       </div>`
    : `<div class="h-44 flex items-center justify-center text-5xl"
            style="background:linear-gradient(135deg,${artifact.color}33,${artifact.color}11)">
         ${CATEGORY_ICONS[artifact.category] || '🏛️'}
       </div>`;

  card.innerHTML = `
    ${imageSection}
    <div class="p-5 flex flex-col flex-1">
      <div class="flex items-start justify-between gap-2 mb-3">
        <span class="text-xs px-2.5 py-0.5 rounded-full pill-${artifact.category}">${escHtml(artifact.category)}</span>
        <span class="text-museum-muted text-xs">${escHtml(artifact.year)}</span>
      </div>
      <h3 class="card-title font-serif text-lg text-museum-text leading-snug mb-2 transition-colors duration-200">${escHtml(artifact.name)}</h3>
      <p class="text-museum-muted text-xs leading-relaxed flex-1 line-clamp-3">${escHtml(artifact.shortDescription)}</p>
      <div class="flex items-center justify-between mt-4 pt-4 border-t border-museum-border">
        <span class="text-museum-muted text-xs">${escHtml(artifact.origin)}</span>
        <span class="text-museum-gold text-xs flex items-center gap-1">
          View artifact
          <svg class="card-arrow w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
          </svg>
        </span>
      </div>
    </div>`;

  card.addEventListener('click', () => openModal(artifact._id));
  return card;
}

// ═════════════════════════════════════════════════════════════════════════════
//  DETAIL MODAL
// ═════════════════════════════════════════════════════════════════════════════

async function openModal(id) {
  try {
    const artifact   = await fetchArtifactById(id);
    currentArtifactId = id;
    populateModal(artifact);
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  } catch (err) {
    console.error('openModal:', err);
  }
}

function closeModal() {
  modal.classList.remove('open');
  document.body.style.overflow = '';
  currentArtifactId = null;
}

function populateModal(artifact) {
  document.getElementById('modal-banner').style.background =
    `linear-gradient(135deg, ${artifact.color}66, ${artifact.color}22)`;

  const img = document.getElementById('modal-image');
  if (artifact.image) { img.src = artifact.image; img.alt = artifact.name; img.style.display = 'block'; }
  else { img.style.display = 'none'; }

  const catEl = document.getElementById('modal-category');
  catEl.textContent = `${CATEGORY_ICONS[artifact.category] || ''} ${artifact.category}`;
  catEl.className   = `relative text-xs px-3 py-1 rounded-full font-medium pill-${artifact.category}`;

  document.getElementById('modal-name').textContent        = artifact.name;
  document.getElementById('modal-year').textContent        = artifact.year;
  document.getElementById('modal-origin').textContent      = artifact.origin;
  document.getElementById('modal-reason').textContent      = artifact.reason;
  document.getElementById('modal-description').textContent = artifact.fullDescription;

  document.getElementById('modal-banned').innerHTML = artifact.bannedIn
    .map((c) => `<span class="text-xs px-2.5 py-0.5 rounded-full bg-red-900/30 text-red-300 border border-red-800/40">${escHtml(c)}</span>`)
    .join('');

  document.getElementById('modal-tags').innerHTML = artifact.tags
    .map((t) => `<span class="text-xs px-2.5 py-0.5 rounded-full bg-museum-bg text-museum-muted border border-museum-border">#${escHtml(t)}</span>`)
    .join('');
}

// Close / backdrop / Escape
document.getElementById('modal-close').addEventListener('click', closeModal);
modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

// Delete artifact from inside the detail modal
document.getElementById('modal-delete-btn').addEventListener('click', async () => {
  if (!currentArtifactId) return;
  if (!confirm('Remove this artifact from the archive? This cannot be undone.')) return;
  try {
    await deleteArtifact(currentArtifactId);
    closeModal();
    await refreshGallery();
    showToast('Artifact removed from the archive.');
  } catch (err) {
    console.error('Delete error:', err);
    showToast('Could not delete artifact.', true);
  }
});

// ═════════════════════════════════════════════════════════════════════════════
//  ADD-ARTIFACT DRAWER
// ═════════════════════════════════════════════════════════════════════════════

function openAddModal() {
  addForm.reset();
  document.getElementById('file-label').textContent = 'Upload image (JPG, PNG, WebP — max 5 MB)';
  document.getElementById('img-preview').classList.add('hidden');
  document.getElementById('img-preview-img').src = '';
  addModal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeAddModal() {
  addModal.classList.remove('open');
  document.body.style.overflow = '';
}

document.getElementById('fab').addEventListener('click', openAddModal);
document.getElementById('add-modal-close').addEventListener('click', closeAddModal);
addModal.addEventListener('click', (e) => { if (e.target === addModal) closeAddModal(); });

// Image file — show preview and update label
document.getElementById('field-image-file').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  document.getElementById('file-label').textContent = file.name;

  const reader = new FileReader();
  reader.onload = (ev) => {
    document.getElementById('img-preview-img').src = ev.target.result;
    document.getElementById('img-preview').classList.remove('hidden');
  };
  reader.readAsDataURL(file);
});

// Clear preview button
document.getElementById('img-preview-clear').addEventListener('click', () => {
  document.getElementById('field-image-file').value = '';
  document.getElementById('img-preview').classList.add('hidden');
  document.getElementById('img-preview-img').src = '';
  document.getElementById('file-label').textContent = 'Upload image (JPG, PNG, WebP — max 5 MB)';
});

// Form submit
addForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const submitBtn = document.getElementById('add-submit-btn');
  submitBtn.disabled    = true;
  submitBtn.textContent = 'Saving…';

  try {
    const formData = new FormData(addForm);
    await createArtifact(formData);
    closeAddModal();
    await refreshGallery();
    showToast('Artifact added to the archive!');
  } catch (err) {
    console.error('Create error:', err);
    showToast(err.message || 'Could not add artifact.', true);
  } finally {
    submitBtn.disabled    = false;
    submitBtn.textContent = 'Add to Archive';
  }
});

// ═════════════════════════════════════════════════════════════════════════════
//  FILTERS & SEARCH
// ═════════════════════════════════════════════════════════════════════════════

document.getElementById('filters').addEventListener('click', async (e) => {
  const btn = e.target.closest('.filter-btn');
  if (!btn) return;
  document.querySelectorAll('.filter-btn').forEach((b) => b.classList.remove('active'));
  btn.classList.add('active');
  activeCategory = btn.dataset.category;
  const artifacts = await fetchArtifacts(activeCategory, searchQuery);
  allArtifacts = artifacts;
  renderGallery(artifacts);
});

let searchTimer;
searchInput.addEventListener('input', (e) => {
  searchQuery = e.target.value.trim();
  clearTimeout(searchTimer);
  searchTimer = setTimeout(async () => {
    const artifacts = await fetchArtifacts(activeCategory, searchQuery);
    allArtifacts = artifacts;
    renderGallery(artifacts);
  }, 350);
});

// Global Escape key — closes whichever overlay is open
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (addModal.classList.contains('open')) closeAddModal();
  else closeModal();
});

// ═════════════════════════════════════════════════════════════════════════════
//  HELPERS
// ═════════════════════════════════════════════════════════════════════════════

// Re-fetch & re-render with the current filter/search state, then update counter
async function refreshGallery() {
  const [filtered, total] = await Promise.all([
    fetchArtifacts(activeCategory, searchQuery),
    fetchArtifacts(),   // always get the unfiltered total for the stat
  ]);
  allArtifacts = filtered;
  statCount.textContent = total.length;
  renderGallery(filtered);
}

function showToast(message, isError = false) {
  const toast    = document.getElementById('toast');
  const toastMsg = document.getElementById('toast-msg');
  toastMsg.textContent = message;
  toast.style.borderColor = isError ? '#7f1d1d' : '';
  toast.classList.remove('translate-y-20', 'opacity-0');
  toast.classList.add('translate-y-0', 'opacity-100');
  setTimeout(() => {
    toast.classList.remove('translate-y-0', 'opacity-100');
    toast.classList.add('translate-y-20', 'opacity-0');
  }, 3000);
}

function showLoading() {
  loading.classList.remove('hidden');
  grid.classList.add('hidden');
  emptyState.classList.add('hidden');
}

function hideLoading() {
  loading.classList.add('hidden');
}

// Sanitise strings injected as HTML to prevent XSS
function escHtml(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ═════════════════════════════════════════════════════════════════════════════
//  INIT
// ═════════════════════════════════════════════════════════════════════════════

(async () => {
  animateHero();
  allArtifacts = await fetchArtifacts();
  statCount.textContent = allArtifacts.length;
  renderGallery(allArtifacts);
})();
