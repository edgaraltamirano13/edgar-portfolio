const express  = require('express');
const router   = express.Router();
const path     = require('path');
const fs       = require('fs');
const multer   = require('multer');
const Artifact = require('../models/Artifact');

// ── Multer — save uploaded images to public/uploads/ ─────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) =>
    cb(null, path.join(__dirname, '../public/uploads')),

  filename: (req, file, cb) => {
    // Use a timestamp + random number to avoid filename collisions
    const ext    = path.extname(file.originalname).toLowerCase();
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, unique + ext);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB max
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp/;
    const okExt   = allowed.test(path.extname(file.originalname).toLowerCase());
    const okMime  = allowed.test(file.mimetype);
    okExt && okMime ? cb(null, true) : cb(new Error('Only image files are allowed'));
  },
});

// ── Helper: split a comma-separated string into a clean array ─────────────────
const splitCSV = (str) =>
  str ? str.split(',').map((s) => s.trim()).filter(Boolean) : [];

// ─────────────────────────────────────────────────────────────────────────────
//  GET /api/artifacts
//  Optional query params: ?category=Literature  &  ?search=keyword
// ─────────────────────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { category, search } = req.query;
    const query = {};

    if (category) query.category = category;

    if (search) {
      query.$or = [
        { name:             { $regex: search, $options: 'i' } },
        { shortDescription: { $regex: search, $options: 'i' } },
        { tags:             { $regex: search, $options: 'i' } },
      ];
    }

    const artifacts = await Artifact.find(query).sort({ year: 1 });
    res.json(artifacts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
//  GET /api/artifacts/featured  (must come before /:id)
// ─────────────────────────────────────────────────────────────────────────────
router.get('/featured', async (req, res) => {
  try {
    const artifacts = await Artifact.find({ featured: true }).limit(6);
    res.json(artifacts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
//  GET /api/artifacts/:id
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const artifact = await Artifact.findById(req.params.id);
    if (!artifact) return res.status(404).json({ message: 'Artifact not found' });
    res.json(artifact);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
//  POST /api/artifacts
//  Accepts multipart/form-data.  The optional file field is named "image".
//  Falls back to the "imageUrl" text field if no file is uploaded.
// ─────────────────────────────────────────────────────────────────────────────
router.post('/', upload.single('image'), async (req, res) => {
  try {
    const d = req.body;

    const artifact = new Artifact({
      name:             d.name,
      year:             d.year,
      origin:           d.origin,
      category:         d.category,
      reason:           d.reason,
      shortDescription: d.shortDescription,
      fullDescription:  d.fullDescription,
      // Uploaded file takes priority over a pasted URL
      image:            req.file ? `/uploads/${req.file.filename}` : (d.imageUrl || ''),
      color:            d.color   || '#8B4513',
      bannedIn:         splitCSV(d.bannedIn),
      tags:             splitCSV(d.tags).map((t) => t.toLowerCase()),
      featured:         d.featured === 'true',
    });

    const saved = await artifact.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
//  DELETE /api/artifacts/:id
// ─────────────────────────────────────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const artifact = await Artifact.findByIdAndDelete(req.params.id);
    if (!artifact) return res.status(404).json({ message: 'Artifact not found' });

    // If the image was an uploaded file (not an external URL), delete it from disk
    if (artifact.image && artifact.image.startsWith('/uploads/')) {
      const filePath = path.join(__dirname, '../public', artifact.image);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }

    res.json({ message: 'Artifact deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
