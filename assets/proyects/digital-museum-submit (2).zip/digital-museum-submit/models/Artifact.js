const mongoose = require('mongoose');

// This schema defines the shape of every artifact document stored in MongoDB.
// Think of it like a blueprint for each museum object.
const artifactSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    year: { type: String, required: true },
    origin: { type: String, required: true },

    // Enum ensures only valid categories can be saved
    category: {
      type: String,
      enum: ['Literature', 'Music', 'Art', 'Film', 'Object', 'Game'],
      required: true,
    },

    reason: { type: String, required: true },
    shortDescription: { type: String, required: true },
    fullDescription: { type: String, required: true },

    image: { type: String, default: '' },

    // Accent color used for the card gradient in the UI
    color: { type: String, default: '#8B4513' },

    // Array of country names where the artifact was banned
    bannedIn: [String],

    tags: [String],

    // Featured artifacts appear in the hero spotlight section
    featured: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Artifact', artifactSchema);
