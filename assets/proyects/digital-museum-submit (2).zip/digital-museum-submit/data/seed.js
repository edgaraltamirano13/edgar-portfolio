// Run with:  npm run seed
// This script clears the database and inserts the default museum artifacts.

require('dotenv').config();
const mongoose = require('mongoose');
const Artifact = require('../models/Artifact');

const artifacts = [
  {
    name: 'Ulysses',
    year: '1922',
    origin: 'Ireland',
    category: 'Literature',
    reason: 'Obscenity and explicit sexual content',
    shortDescription:
      "James Joyce's modernist masterpiece was banned in the US for over a decade after being serialised in a literary magazine.",
    fullDescription:
      "James Joyce's Ulysses is considered one of the most important works in modernist literature, yet it faced severe censorship when first published. The novel was serialised in the American literary magazine The Little Review from 1918 to 1920. After legal proceedings for obscenity, the US Postal Service burned issues containing the novel's passages. The book was officially banned in the United States until 1933, when Judge John M. Woolsey ruled that the explicit passages did not corrupt the average reader. The novel was also banned in the UK until 1936. Today it is celebrated as one of humanity's greatest artistic achievements.",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Ulysses_cover_1922.jpg/400px-Ulysses_cover_1922.jpg',
    color: '#2D4A3E',
    bannedIn: ['USA', 'UK', 'Ireland', 'Canada'],
    tags: ['literature', 'censorship', 'obscenity', 'modernism', 'joyce'],
    featured: true,
  },
  {
    name: "Lady Chatterley's Lover",
    year: '1928',
    origin: 'United Kingdom',
    category: 'Literature',
    reason: 'Explicit sexual content and use of vulgar language',
    shortDescription:
      "D.H. Lawrence's novel about a love affair between a working-class gamekeeper and an aristocratic woman was banned for three decades.",
    fullDescription:
      "D.H. Lawrence's Lady Chatterley's Lover was privately printed in Florence in 1928 but was not legally published in the UK until 1960, after a famous obscenity trial. The novel explores the relationship between Lady Constance Chatterley and her husband's gamekeeper, Oliver Mellors. Its explicit sexual passages and use of four-letter words made it a target for censors across the English-speaking world. The 1960 Penguin Books trial, which resulted in acquittal, became a landmark moment for freedom of expression in Britain. The prosecution famously asked the jury whether it was 'a book you would wish your wife or servants to read.'",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/LadyChatterleysLover.jpg/400px-LadyChatterleysLover.jpg',
    color: '#5C2626',
    bannedIn: ['UK', 'USA', 'Australia', 'Canada', 'Japan'],
    tags: ['literature', 'censorship', 'sexuality', 'class', 'lawrence'],
    featured: true,
  },
  {
    name: 'The Catcher in the Rye',
    year: '1951',
    origin: 'USA',
    category: 'Literature',
    reason: 'Profanity, sexual content, and anti-establishment themes',
    shortDescription:
      "J.D. Salinger's coming-of-age novel has been one of the most challenged books in American schools since its publication.",
    fullDescription:
      "J.D. Salinger's The Catcher in the Rye follows teenager Holden Caulfield through New York City after his expulsion from prep school. Since its 1951 publication, it has been one of the most challenged books in the United States. It was removed from school reading lists due to its profanity, sexual references, and what some considered a negative portrayal of authority figures. It was also linked to the assassination attempt on President Reagan in 1981, as shooter John Hinckley Jr. had a copy in his possession. Ironically, the controversy only increased its popularity, making it a symbol of teenage rebellion and independent thought.",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Holden-Caulfield-Catcher-Rye.jpg/400px-Holden-Caulfield-Catcher-Rye.jpg',
    color: '#7A3B1E',
    bannedIn: ['Various US school districts', 'Australia (1956–1958)'],
    tags: ['literature', 'censorship', 'youth', 'rebellion', 'salinger'],
    featured: true,
  },
  {
    name: 'Nineteen Eighty-Four',
    year: '1949',
    origin: 'United Kingdom',
    category: 'Literature',
    reason: 'Anti-Soviet sentiment and criticism of totalitarian governments',
    shortDescription:
      "George Orwell's dystopian novel about totalitarianism and state surveillance was banned across the entire communist bloc.",
    fullDescription:
      "George Orwell's Nineteen Eighty-Four depicts a dystopian society under total government surveillance and ideological control. The novel was banned in the USSR and other communist bloc countries during the Cold War, as it was seen as a direct critique of Stalinist Soviet Union. The Party's slogan — 'War is Peace, Freedom is Slavery, Ignorance is Strength' — was a direct parody of Soviet propaganda. It was also removed from some American school libraries during the McCarthy era for its perceived subversive content. Ironically, the novel's themes of government overreach and censorship made its own banning a self-fulfilling prophecy.",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/1984first.jpg/400px-1984first.jpg',
    color: '#1A1A2E',
    bannedIn: ['USSR', 'China', 'North Korea', 'Various US schools'],
    tags: ['literature', 'politics', 'dystopia', 'surveillance', 'orwell'],
    featured: true,
  },
  {
    name: 'Monopoly',
    year: '1935',
    origin: 'USA',
    category: 'Game',
    reason: 'Promotion of capitalist ideology',
    shortDescription:
      "The world's most famous board game was banned in the Soviet Union as propaganda for capitalism and private ownership.",
    fullDescription:
      "The Monopoly board game, created by Charles Darrow and published by Parker Brothers in 1935, was banned in the Soviet Union from 1959 to 1991. Soviet authorities considered it a capitalist propaganda tool that promoted private ownership and the accumulation of wealth — values antithetical to communist ideology. Interestingly, the game's original inventor, Elizabeth Magie, had created it as a critique of monopolistic practices, not as a celebration of capitalism. Despite the ban, some Soviet citizens managed to obtain contraband copies. Today, Monopoly is sold in 103 countries and has been translated into 37 languages.",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Monopoly_board_on_white_bg.jpg/400px-Monopoly_board_on_white_bg.jpg',
    color: '#B8860B',
    bannedIn: ['USSR', 'Cuba', 'North Korea'],
    tags: ['game', 'capitalism', 'cold war', 'ideology', 'board game'],
    featured: true,
  },
  {
    name: 'The Satanic Verses',
    year: '1988',
    origin: 'United Kingdom',
    category: 'Literature',
    reason: 'Blasphemy and perceived insults to Islam',
    shortDescription:
      "Salman Rushdie's magical-realist novel caused international controversy and led to a fatwa calling for the author's death.",
    fullDescription:
      "Salman Rushdie's The Satanic Verses ignited a firestorm of international controversy upon its publication in 1988. The novel's magical-realist treatment of Islam's founding led Ayatollah Khomeini of Iran to issue a fatwa — a religious decree — calling for Rushdie's death. The book was banned in India, Pakistan, South Africa, Egypt, and many other countries with significant Muslim populations. Rushdie was forced to live under police protection for nearly a decade. In 2022, he was attacked by a knife-wielding assailant in New York, losing sight in one eye. The novel remains one of the most internationally controversial books ever published.",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Satanic_Verses.jpg/400px-Satanic_Verses.jpg',
    color: '#3D0C02',
    bannedIn: ['India', 'Pakistan', 'Saudi Arabia', 'Egypt', 'Iran', 'Bangladesh'],
    tags: ['literature', 'religion', 'blasphemy', 'fatwa', 'rushdie'],
    featured: false,
  },
  {
    name: "Billie Holiday – 'Strange Fruit'",
    year: '1939',
    origin: 'USA',
    category: 'Music',
    reason: 'Graphic depiction of lynching and racial violence',
    shortDescription:
      "Billie Holiday's haunting protest song about the lynching of Black Americans was banned by NBC and radio stations across the South.",
    fullDescription:
      "'Strange Fruit' is a protest song performed by jazz legend Billie Holiday. Written by Abel Meeropol, the lyrics graphically describe the lynching of Black Americans in the South using the disturbing metaphor of bodies hanging like 'strange fruit' from trees. The song was banned by many radio stations, particularly in the South, and NBC forbade Holiday from performing it on the air. Columbia Records also refused to record it, forcing Holiday to seek a smaller label. Despite — or because of — the controversy, it became one of the most powerful protest songs in American history. In 1999, Time magazine named it the 'Song of the Century.'",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Billie_Holiday_1949.jpg/400px-Billie_Holiday_1949.jpg',
    color: '#1A0A00',
    bannedIn: ['NBC (USA)', 'Various Southern US radio stations'],
    tags: ['music', 'racism', 'civil rights', 'protest', 'jazz', 'holiday'],
    featured: false,
  },
  {
    name: "Rubik's Cube",
    year: '1974',
    origin: 'Hungary',
    category: 'Object',
    reason: 'Symbol of Western capitalism during the Cold War',
    shortDescription:
      "The iconic puzzle cube, invented in communist Hungary, was ironically banned in Romania as a symbol of Western decadence.",
    fullDescription:
      "The Rubik's Cube, invented by Hungarian sculptor and professor Ernő Rubik in 1974, became a global phenomenon in the 1980s. However, in communist Romania under Nicolae Ceaușescu, the cube was viewed as a symbol of Western capitalism and was banned. The irony is profound: the cube was invented inside the Eastern Bloc itself. Despite restrictions, many Romanians managed to obtain and secretly play with the puzzle. The cube also faced limited distribution across the USSR due to ideological concerns about a toy that promoted individual problem-solving over collective thinking. Today it is the world's best-selling toy, with over 450 million units sold.",
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/JavaScript_rubik_cube.gif/400px-JavaScript_rubik_cube.gif',
    color: '#C0392B',
    bannedIn: ['Romania', 'Restricted in USSR'],
    tags: ['toy', 'cold war', 'capitalism', 'puzzle', 'hungary'],
    featured: false,
  },
  {
    name: 'Harry Potter Series',
    year: '1997',
    origin: 'United Kingdom',
    category: 'Literature',
    reason: 'Witchcraft, sorcery, and promotion of occultism',
    shortDescription:
      "J.K. Rowling's beloved fantasy series was banned by numerous religious schools and communities for allegedly promoting witchcraft.",
    fullDescription:
      "J.K. Rowling's Harry Potter series became a worldwide phenomenon, but it also became one of the most challenged book series in modern history. Conservative religious groups in the United States and elsewhere argued that the books promoted witchcraft and the occult, and could lead children toward Satanism. Numerous school districts and church communities banned the series from their libraries. In 2019, a Catholic school in Nashville removed the books, claiming the spells in the novels were 'real' and could summon evil spirits. Despite — and partly because of — these controversies, the series sold over 500 million copies worldwide and inspired a generation of readers.",
    image: 'https://upload.wikimedia.org/wikipedia/en/thumb/6/6b/Harry_Potter_and_the_Philosopher%27s_Stone_Book_Cover.jpg/400px-Harry_Potter_and_the_Philosopher%27s_Stone_Book_Cover.jpg',
    color: '#4B0082',
    bannedIn: ['Various US school districts', 'Various religious communities worldwide'],
    tags: ['literature', 'fantasy', 'religion', 'witchcraft', 'rowling'],
    featured: true,
  },
];

async function seedDatabase() {
  try {
    await mongoose.connect(
      process.env.MONGODB_URI || 'mongodb://localhost:27017/digital-museum'
    );
    console.log('✅  Connected to MongoDB');

    await Artifact.deleteMany({});
    console.log('🗑️   Cleared existing artifacts');

    const inserted = await Artifact.insertMany(artifacts);
    console.log(`🌱  Seeded ${inserted.length} artifacts successfully`);

    await mongoose.connection.close();
    console.log('✅  Done! Run "npm run dev" to start the server.');
  } catch (err) {
    console.error('❌  Seeding error:', err);
    process.exit(1);
  }
}

seedDatabase();
