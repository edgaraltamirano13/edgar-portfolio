@echo off
title Digital Museum - Server
echo.
echo  ==========================================
echo   THE FORBIDDEN ARCHIVE - Digital Museum
echo  ==========================================
echo.
echo  Starting server...
echo  When you see the address, open your browser
echo  and go to:  http://localhost:3000
echo.
echo  To stop the server, close this window.
echo  ==========================================
echo.

cd /d "%~dp0"
npm run dev

pause
