require('dotenv').config();
const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const path     = require('path');
const fs       = require('fs');

const app  = express();
const PORT = process.env.PORT || 3000;

// Ensure uploads folder exists
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── API Routes ────────────────────────────────────────────────────────────────
app.use('/api/artifacts', require('./routes/artifacts'));

app.get('*', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'index.html'))
);

// ── Database + Server startup ─────────────────────────────────────────────────
async function start() {
  const configUri = process.env.MONGODB_URI || '';

  console.log('🔍  MONGODB_URI set:', configUri ? 'YES' : 'NO');

  if (configUri) {
    await mongoose.connect(configUri);
    console.log('✅  Connected to MongoDB');
  } else {
    console.log('🔄  Starting built-in database…');
    console.log('    (First run downloads ~70 MB — please wait)');

    const { MongoMemoryServer } = require('mongodb-memory-server');
    const mongod = await MongoMemoryServer.create();
    await mongoose.connect(mongod.getUri() + 'digital-museum');
    console.log('✅  Built-in database ready');

    // Auto-seed every time (data lives only in memory while the server runs)
    const Artifact  = require('./models/Artifact');
    const seedData  = require('./data/seedData');
    await Artifact.deleteMany({});
    await Artifact.insertMany(seedData);
    console.log(`🌱  Loaded ${seedData.length} artifacts`);
  }

  app.listen(PORT, () => {
    console.log(`\n🏛️   Museum running → http://localhost:${PORT}\n`);
  });
}

start().catch((err) => {
  console.error('❌  Startup error:', err);
  process.exit(1);
});
